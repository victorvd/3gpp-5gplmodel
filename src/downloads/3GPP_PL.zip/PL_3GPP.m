function PL_dB = PL_3GPP(fc,d2D,hBS,hUT,h,W,sceType,envType)

%PL3GPP
%PL3GPP function returns the path loss value for RMa, UMa, UMi
%and InH scenarios
%- fc is the center frequency / carrier frequency in GHz.
%- d2D is the 2D distance between Tx and Rx in m.
%- hBS is the antenna height for BS in m.
%- hUT is the antenna height for UT.
%- h is the average building height in m. Required only for RMa scenario.
%- W is the average street width in m. Required only for RMa scenario.
%- sceType is the scenario: 'RMa', 'UMa', 'UMi' and 'InH'.
%- envType is the LoS condition: 'LoS' or 'NLoS'.

c=3.0e8;
d3D=sqrt(d2D^2+(hBS-hUT)^2);

switch sceType
    case 'RMa'
        dBP = 2*pi*hBS*hUT*fc*1e9/c;
        %LoS
        if d2D <= dBP && d2D >= 10
            SF = 4;
            PL_dB = 20*log10(40*pi*d3D*fc/3)+min(0.03*h^1.72,10)*log10(d3D)-min(0.044*h^1.72,14.77)+0.002*log10(h)*d3D;
            stdSF = normalDistribution(0, SF);
        elseif d2D <= 10000 && d2D >= dBP
            SF = 6;
            PL_dB = 20*log10(40*pi*dBP*fc/3)+min(0.03*h^1.72,10)*log10(dBP)-min(0.044*h^1.72,14.77)+0.002*log10(h)*dBP+40*log10(d3D/dBP);
            stdSF = SF*randn;
        else
            PL_dB = NaN;
            stdSF = NaN;
        end
        if strcmp(envType,'NLoS')
            if d2D <= 5000 && d2D >= 10
                SF = 8;
                PLRMa_p = 161.04-7.1*log10(W)+7.5*log10(h)-(24.37-3.7*(h/hBS)^2)*log10(hBS)+(43.42-3.1*log10(hBS))*(log10(d3D)-3)+20*log10(fc)-(3.2*log10(11.75*hUT)^2-4.97);
                PL_dB = max(PL_dB,PLRMa_p);
                stdSF = normalDistribution(0, SF);
            else
                PL_dB = NaN;
                stdSF = NaN;
            end
        end
    case 'UMa'
        hE = 1;
        h_BS = hBS-hE;
        h_UT = hUT-hE;
        dBPp = 4*h_BS*h_UT*fc*1e9/c;
        %LoS
        SF = 4;
        if d2D <= dBPp && d2D >= 10
            PL_dB = 28+22*log10(d3D)+20*log10(fc);
        elseif d2D <= 5000 && d2D >= dBPp
            PL_dB = 28+40*log10(d3D)+20*log10(fc)-9*log10(dBPp^2+(hBS-hUT)^2);
        else
            PL_dB = NaN;
            stdSF = NaN;
        end
        stdSF = normalDistribution(0, SF);
        if strcmp(envType,'NLoS')
            SF = 6;
            if d2D <= 5000 && d2D >= 10
                PLUMa_p = 13.54+39.08*log10(d3D)+20*log10(fc)-0.6*(hUT-1.5);
                PL_dB = max(PL_dB,PLUMa_p);
                stdSF = normalDistribution(0, SF);
            else
                PL_dB = NaN;
                stdSF = NaN;
            end
        end
    case 'UMi'
        hE = 1;
        h_BS = hBS-hE;
        h_UT = hUT-hE;
        dBPp = 4*h_BS*h_UT*fc*1e9/c;
        %LoS
        SF = 4.0;
        if d2D <= dBPp && d2D >= 10
            PL_dB = 32.4+21*log10(d3D)+20*log10(fc);
        elseif d2D <= 5000 && d2D >= dBPp
            PL_dB = 32.4+40*log10(d3D)+20*log10(fc)-9.5*log10(dBPp^2+(hBS-hUT)^2);
        else
            PL_dB = NaN;
            stdSF = NaN;
        end
        stdSF = normalDistribution(0, SF);
        
        if strcmp(envType,'NLoS')
            SF = 7.82;
            if d2D <= 5000 && d2D >= 10
                PLUMi_p = 22.4+35.3*log10(d3D)+21.3*log10(fc)-0.3*(hUT-1.5);
                PL_dB = max(PL_dB,PLUMi_p);
            else
                PL_dB = NaN;
                stdSF = NaN;
            end
        end
    case 'InH'
        %LoS
        SF = 3.0;
        if d3D <= 150 && d3D >= 1
            PL_dB = 32.4+17.3*log10(d3D)+20*log10(fc);
        else
            PL_dB = NaN;
            stdSF = NaN;
        end
        stdSF = normalDistribution(0, SF);;
        
        if strcmp(envType,'NLoS')
            SF = 8.03;
            if d3D <= 150 && d3D >= 1
                PLInH_p = 17.3+38.3*log10(d3D)+24.9*log10(fc);
                PL_dB = max(PL_dB,PLInH_p);
            else
                PL_dB = NaN;
                stdSF = NaN;
            end
            stdSF = normalDistribution(0, SF);
        end
end

PL_dB = PL_dB + stdSF;

%Function end
end

function z0 = normalDistribution(mu, sigma)

u1 = 0;
u2 = 0;

while (u1 == 0)   %Turn [0,1) to (0,1)
    u1 = rand;  %Generate float random number between 0 and 1
end

while (u2 == 0)
    u2 = rand;
end

z0 = sqrt(-2.0 * log(u1)) * cos(pi * 2 * u2);
z1 = sqrt(-2.0 * log(u1)) * sin(pi * 2 * u2);

z0 = z0 * sigma + mu;

end