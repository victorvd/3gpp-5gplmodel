%PL models comparisson, NYU and 3GPP for 5G spectrum
%This script returns the corresponding semilog graphs to the scenarios
%for both NYU and 3GPP models.
%It can also be modified to return a graph for a single scenario or for
%several, and for one model or both.
%To make modifications uncomment and comment lines as needed.

%Uncomment line 127 in PL_NYU
%Comment line 123 in PL_3GPP

%Uncomment chosen scenario. Leave or change the other parameters
    sceType = 'RMa'; fc = 28; hBS = 35; hUT = 1.5;  h = 5; W = 20;
    %sceType = 'UMa'; fc = 28; hBS = 25; hUT = 1.5; h = 0; W = 0;
    %sceType = 'UMi'; fc = 28; hBS = 10; hUT = 1.5; h = 0; W = 0;
    %sceType = 'InH'; fc = 4; hBS = 3; hUT = 1; h = 0; W = 0;
%Choose to compare one scenario or many
    %sceType_ar= {sceType}; %One scenario taken from chosen scenario
    sceType_ar= {'RMa' 'UMa' 'UMi'}; %Many scenarios
%Choose line-of-sight
    envType_ar = {'LoS'};
    %envType_ar = {'NLoS'};
%Other variables
f = fc; h_BS = hBS; TXPower = 30;
c = 3.0e8;  %speed of light
ni = 10;    %initial distance value
n0 = 10000; %final distance value

dBP = 2*pi*hBS*hUT*fc*1e9/c;
dBPp = 4*(hBS-1)*(hUT-1)*fc*1e9/c;

for k=1:length(envType_ar)
    for j=1:length(sceType_ar)
        for i=ni:n0
            NYU_2(i+1-ni,j) = PL_NYU(f,i,h_BS,TXPower,sceType_ar{j},envType_ar{k});
            TGPP_2(i+1-ni,j) = PL_3GPP(fc,i,hBS,hUT,h,W,sceType_ar{j},envType_ar{k});
            d3D_2(i+1-ni) = sqrt(i^2+(hBS-hUT)^2);
            TRDistance_2(i+1-ni) = i;
        end
        
        sl1 = semilogx(d3D_2,TGPP_2(:,j),'LineWidth',1);
        hold on
        sl2 = semilogx(TRDistance_2,NYU_2(:,j),'LineWidth',1);
        %%Uncomment to draw dBP vertical line
            %if strcmp(sceType,'RMa')
            %	l1 = line([dBP dBP],[0 max(max(TGPP_2),max(NYU_2))],'Color','k');
            %elseif (strcmp(sceType,'UMa') || strcmp(sceType,'UMi'))
            %	l1 = line([dBPp dBPp],[0 max(max(TGPP_2),max(NYU_2))],'Color','k');
            %end
            %legend([sl1 sl2 l1],{sprintf('%s %s %s','3GPP',sceType_ar{k},envType_ar{j}),sprintf('%s %s %s','NYU',sceType_ar{k},envType_ar{j}),'Breakpoint'});
        lgn{1,k,j} = sprintf('%s %s %s','3GPP',sceType_ar{j},envType_ar{k});
        lgn{2,k,j} = sprintf('%s %s %s','NYU',sceType_ar{j},envType_ar{k});
        
        leg(1,k,j)=string(lgn{1,k,j});
        leg(2,k,j)=string(lgn{2,k,j});
        
        xlim([ni n0])
        grid on;
    end
end
legend(leg)
title(sprintf('%s %s, %s, %s %s %s','Path loss para:',string(sceType_ar),' - ',string(envType_ar)))
xlabel('Distancia T-R [m]') % x-axis label
ylabel('Path loss [dB]') % y-axis label