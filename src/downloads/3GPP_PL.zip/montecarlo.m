%Monte Carlo simulation
%This script runs a Monte Carlo simulation in order to compare both
%models: NYU and 3GPP. It returns histograms for a set of single parameters
%declared and the start, running n iterations (10000 by default).
%It can also be modified to return a distance vs path loss semilog graph.
%To make modifications uncomment and comment lines as needed.

%Comment line 127 in PL_NYU
%Uncomment line 123 in PL_3GPP

%Uncomment chosen scenario, comment the others. Leave or change the parameters
    sceType = 'RMa'; envType = 'LoS'; fc = 7; f = fc; d2D =35; TRDistance = d2D;
    	hBS = 35; h_BS = hBS; hUT = 1.5; TXPower = 30; h = 5; W = 20;
    %sceType = 'UMa'; envType = 'LoS'; fc = 28; f = fc; d2D =35; TRDistance = d2D;
    %   hBS = 25; h_BS = hBS; hUT = 1.5; TXPower = 30;  h = 0; W = 0;
    %sceType = 'UMi'; envType = 'LoS'; fc = 28; f = fc; d2D =10; TRDistance = d2D;
    %    hBS = 10; h_BS = hBS; hUT = 1.5; TXPower = 30; h = 0; W = 0;
%Variables declaration
n = 10000;  %number of iterations
m = 1;  %number of iterations of iterations (m = 50);
%%Uncomment for using range of distances instead of one distance
    %d = linspace(10,10000,m);
    %d2D = d;
    %TRDistance = d;
d3D = sqrt(d2D.^2+(hBS-hUT)^2);

for j=1:m
    for i=1:n
    %%Uncomment to use random variables
        %fc = (30-0.5).*rand() + 0.5; f = fc;
        %d2D =(5000-10).*rand() + 10; TRDistance = d2D;
        %BS = (150-10).*rand() + 10; h_BS = hBS;
        %hUT = (10-1).*rand() + 1;
        %h = (50-5).*rand() + 5;
        %W = (50-5).*rand() + 5;
        
        NYU(i,j) = PL_NYU(f,d2D(j),h_BS,TXPower,sceType,envType);
        TGPP(i,j) = PL_3GPP(fc,TRDistance(j),hBS,hUT,h,W,sceType,envType);
        diff(i,j) = NYU(i,j)-TGPP(i,j);
    end
    
    %Statistics
    media_NYU(j) = mean(NYU(:,j))
    media_3GPP(j) = mean(TGPP(:,j))
    desv_std(j) = std(diff(:,j))
    promedio_dif(j) = mean(diff(:,j))
    
end
%Graphs
h1 = histogram(NYU);
hold on

h2 = histogram(TGPP);
l1 = line([mean(NYU) mean(NYU)],[0 max(h2.Values)],'Color','red','LineWidth',1.5);
hold on
grid on

l2 = line([mean(TGPP) mean(TGPP)],[0 max(h2.Values)],'Color','green','LineWidth',1.5);

title(sprintf('%s %s %s','Histograma',sceType,envType))
legend([h1 h2 l1 l2],{'NYU','3GPP','Media NYU','Media 3GPP'});
xlabel('Path loss promedio [dB]') % x-axis label
ylabel('N� de iteraciones') % y-axis label

%Semilog graph for range of distances (line 15)
    % g1=semilogx(d,media_NYU);
    % hold on
    % g2=semilogx(d3D,media_3GPP);
    % legend([g1 g2],{'Media NYU','Media 3GPP'});
    %
    % g3=plot(desv_std);
    % hold on
    % g4=plot(promedio_dif);
    % legend([g3 g4],{'Desv_est','Prom_dif'});

%Monte Carlo simulation with random variables graph (line 23)
    % g1=plot(1:n,diff(:,1),'b');
    % hold on;
    % g2=plot(1:n,ones(n,1).*promedio_dif(1),'r','LineWidth',1.5);
    % grid on;
    % legend([g1 g2],{'Diferencia NYU-3GPP','Promedio'});
    % title(sprintf('%s %s %s',sceType,envType,'modelos NYU-3GPP para variables aleatorias'))

    % h1 = histogram(diff);
    % hold on;
    % l1 = line([promedio_dif promedio_dif],[0 max(h1.Values)],'Color','red','LineWidth',1.5);
    % title(sprintf('%s %s %s','Histograma',sceType,envType))
    % xlabel('Diferencia media [dB]') % x-axis label
    % ylabel('N� de iteraciones') % y-axis label
    % legend([h1 l1],{'Distrib. de la diferencia','Diferencia media'});
    % grid on;