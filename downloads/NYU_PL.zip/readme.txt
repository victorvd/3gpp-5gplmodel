%%% NYUSIM - User License %%%

% Copyright (c) 2017 New York University and NYU WIRELESS

Execute the file:
	- PL_NYU.m
It requieres the other M files to execute.