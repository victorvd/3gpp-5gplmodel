function [PL_dB,Pr_dBm,PLE] = PL_NYU(f,TRDistance,h_BS,TXPower,sceType,envType)

%%% NYUSIM - User License %%%

% Copyright (c) 2017 New York University and NYU WIRELESS

% Permission is hereby granted, free of charge, to any person obtaining a 
% copy of this software and associated documentation files (the �Software�),
% to deal in the Software without restriction, including without limitation 
% the rights to use, copy, modify, merge, publish, distribute, sublicense, 
% and/or sell copies of the Software, and to permit persons to whom the 
% Software is furnished to do so, subject to the following conditions:

% The above copyright notice and this permission notice shall be included
% in all copies or substantial portions of the Software. Users shall cite 
% NYU WIRELESS publications regarding this work.

% THE SOFTWARE IS PROVIDED �AS IS�, WITHOUTWARRANTY OF ANY KIND, EXPRESS OR 
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
% THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR 
% OTHER LIABILITY, WHETHER INANACTION OF CONTRACT TORT OR OTHERWISE, 
% ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR 
% OTHER DEALINGS IN THE SOFTWARE.

% NYUSIM_MainCode Version 1.6, developed by:
%
% Shu Sun, Mathew Samimi - NYU WIRELESS, December 2017
%
% This script shows an example of how to generate output figures of NYUSIM 
% without the need to open the graphical user interface (GUI) of NYUSIM.
% Users can modify this script per their own needs, such as modifying
% channel parameters and creating data files, etc. For more detailed
% information about the code, please refer to the user manual of NYUSIM 
% (http://wireless.engineering.nyu.edu/nyusim/) and references therein.
%
% Note: This code was written on a Mac OS, fontsizes displayed in figures
% may need to be adjusted by the user if operating on a Windows OS.
% 
% See REFERENCES below and the NYUSIM user manual for more information:
%
% [1] S. Sun, G. R. MacCartney, and T. S. Rappaport, "A novel 
% millimeter-wave channel simulator and applications for 5G wireless 
% communications," 2017 IEEE International Conference on Communications 
% (ICC), Paris, France, 2017, pp. 1-7.
%
% [2] M. K. Samimi and T. S. Rappaport, "3-D Millimeter-Wave Statistical 
% Channel Model for 5G Wireless System Design," in IEEE Transactions on 
% Microwave Theory and Techniques, vol. 64, no. 7, pp. 2207-2225, Jul. 2016.
%
% [3] S. Sun et al., "Investigation of Prediction Accuracy, Sensitivity, 
% and Parameter Stability of Large-Scale Propagation Path Loss Models for 
% 5G Wireless Communications," in IEEE Transactions on Vehicular Technology, 
% vol. 65, no. 5, pp. 2843-2860, May 2016.

%PL_NYU
%La funci�n NYU devuelve el valor de las p�rdidas en el trayecto para
%LoS escenarios RMa, UMa e UMi.
%- f es la frecuencia central en GHz.
%- TRDistance es la distancia 2D entre la BS y el UT en m.
%- h_BS es la altura de la estaci�n base en m.
%- TXPower es la potencia del transmisor en dBm.
%- sceType puede tomar el valor de 'RMa', 'UMa', 'UMi' e 'InH'.
%- envType puede tomar el valor de 'LoS' o 'NLoS'.

% Carrier frequency in GHz (0.5-100 GHz)
    %f = 28; freq = num2str(f);
% Operating scenario, can be UMi (urban microcell),UMa (urban macrocell),
% or RMa (Rural macrocell)
    %sceType = 'UMi';
% Operating environment, can be LoS (line-of-sight) or NLoS (non-line-of-sight)
    %envType = 'LoS';
% Minimum and maximum T-R separation distance (10-10,000 m)
    %dmin = 10; dmax = 10000;
% Transmit power in dBm (0-50 dBm)
    %TXPower = 30;
% Base station height in meters (10-150 m), only used for the RMa scenario
    %h_BS = 35;
% Barometric Pressure in mbar (1e-5 to 1013.25 mbar)
p = 1013.25;
% Humidity in % (0-100%)
u = 50;
% Temperature in degrees Celsius (-100 to 50 degrees Celsius)
t = 20;
% Rain rate in mm/hr (0-150 mm/hr)
RR = 0;
% Foliage attenuation in dB/m (0-10 dB/m)
folAtt = 0.4;
% Foliage LoSs
Fol = 'No';
% Distance within foliage in meters (0-dmin)
dFol = 0;
%%% Channel Model Parameters
% Free space reference distance in meters
d0 = 1;
% Speed of light in m/s
c = 3e8;
switch sceType
    case 'RMa'
        if strcmp(envType,'LoS')
            n = 2.31;
            SF = 1.7;
        elseif strcmp(envType,'NLoS')
            n = 3.07;
            SF = 6.7;
        end
    case 'UMa'
        if strcmp(envType,'LoS')
            n = 2.0;
            SF = 4.0;
        elseif strcmp(envType,'NLoS')
            n = 2.9;
            SF = 7.0;
        end
    case 'UMi'
        if strcmp(envType,'LoS')
            n = 2.0;
            SF = 4.0;
        elseif strcmp(envType,'NLoS')
            n = 3.2;
            SF = 7.0;
        end
    otherwise
        n = NaN;
        SF = NaN;
end
%SF = 0;
PL_dB = NaN;
% Step 1: Generate T-R Separation distance (m) ranging from dmin - dmax.
    %clear TRDistance; TRDistance = getTRSep(dmin,dmax);
% Step 2: Generate the total received omnidirectional power (dBm) and
% omnidirectional path LoSs (dB)
% non RMa, i.e., UMi or UMa
if strcmp(sceType,'RMa') == false
    [Pr_dBm, PL_dB]= getRXPower(f,n,SF,TXPower,TRDistance,d0);
    % RMa LoS
elseif strcmp(sceType,'RMa') == true && strcmp(envType,'LoS') == true
    PL_dB = 20*log10(4*pi*d0*f*1e9/c) + 23.1*(1-0.03*((h_BS-35)/35))*log10(TRDistance) + SF*randn;
    % RMa NLoS
elseif strcmp(sceType,'RMa') == true && strcmp(envType,'NLoS') == true
    PL_dB = 20*log10(4*pi*d0*f*1e9/c) + 30.7*(1-0.049*((h_BS-35)/35))*log10(TRDistance) + SF*randn;
end
% Atmospheric attenuation factor
attenFactor = mpm93_forNYU(f,p,u,t,RR);
% Path LoSs incorporating atmospheric attenuation
PL_dB = getAtmosphericAttenuatedPL(PL_dB,attenFactor,TRDistance);
% Incorporating foliage LoSs
if strcmp(Fol,'Yes') == true
    PL_dB = getFoliageAttenuatedPL(PL_dB,folAtt,dFol);
end
% Calculate received power based on transmit power and path LoSs
Pr_dBm = TXPower - PL_dB;
% Free space path LoSs
FSPL = 20*log10(4*pi*d0*f*1e9/c);
% PLE
PLE = (PL_dB-FSPL)/(10*log10(TRDistance/d0));